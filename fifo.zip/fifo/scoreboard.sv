class scoreboard;
transaction tr1,tr2;
mailbox #(transaction) i2s,o2s;
function new(input mailbox #(transaction)i2s,o2s);
this.i2s=i2s;
this.o2s=o2s;
endfunction
task run();
tr1=new();
tr2=new();
forever begin
i2s.get(tr1);
o2s.get(tr2);
tr1.display("from inputmonitor of scoreboard");
tr2.display("from outputmonitor of scoreboard");
if(tr1.dout==tr2.dout)
    $display("---------------------------test passed----------------------------");
    else
        $display("--------------------------test failed----------------------------------");
        end
        endtask
        endclass
