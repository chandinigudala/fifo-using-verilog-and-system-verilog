class driver;
transaction tr;
mailbox #(transaction) g2d;
virtual interface_fifo inter;
function new(input mailbox #(transaction) g2d,virtual interface_fifo inter);
this.g2d=g2d;
this.inter=inter;
endfunction
task run();
tr=new();
forever begin
wait(tr.rst==0) begin
g2d.get(tr);
tr.display("from driver");
inter.din=tr.din;
inter.e  = tr.e;
$display("*********************din:%d*****************",inter.din);
end
end
endtask
endclass
