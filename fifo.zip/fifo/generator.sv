class generator;
transaction tr;
mailbox #(transaction) g2d;
function new(input mailbox #(transaction) g2d);
this.g2d=g2d;
endfunction
task run();
#1;
tr=new();
send();
#10;
receive();
endtask
task send();
tr.e=1;
for(int i=0; i<=15; i++) begin
    tr.randomize();
        g2d.put(tr);
#10;
    end
    endtask
    task receive();
     tr.e=0;
    for(int j=0; j<=15; j++) begin
        tr.randomize();
        g2d.put(tr);
#10;
        end
        endtask
endclass


