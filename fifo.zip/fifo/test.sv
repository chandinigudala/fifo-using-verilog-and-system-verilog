class test;
env e;
virtual interface_fifo inter;
function new(input virtual interface_fifo inter);
this.inter=inter;
endfunction
task run();
e=new(inter);
e.run();
endtask
endclass

