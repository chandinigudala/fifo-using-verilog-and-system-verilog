class inputmonitor;
transaction tr;
reg [3:0]mem[15:0];
reg [4:0]rd;
reg [4:0]wr;
mailbox #(transaction) i2s;
virtual interface_fifo inter;
function new(input mailbox #(transaction) i2s,virtual interface_fifo inter);
this.i2s=i2s;
this.inter=inter;
endfunction
task run();
tr=new();
forever begin
@(posedge inter.clk)
tr.din=inter.din;
tr.clk=inter.clk;
tr.rst=inter.rst;
tr.e=inter.e;
tr.display("from inputmonitor");
i2s.put(tr);
bfm();
$display("************e:%b,full:%b,empty:%d,din:%d,dout:%d************************",tr.e,tr.full,tr.empty,tr.din,tr.dout);
end
endtask
task bfm();
//reg [3:0]mem[15:0];
if(tr.rst==1) begin
    tr.dout=0;
   // tr.empty=0;
    //tr.full=0;
    wr=0;
    rd=0;
    for(int i=0; i<=15;i++)
        mem[i]=0;
        end
        else begin
            if(tr.e==1 && !tr.full) begin
                mem[wr[3:0]]=tr.din;
                wr=wr+1;
                end
                else if(tr.e==0 && !tr.empty) begin
                    tr.dout=mem[rd[3:0]];
                    rd=rd+1;
                    end
                    end
                     tr.empty=(rd==wr);
                    tr.full=((wr[4]!=rd[4])  && (wr[3:0]==rd[3:0]));

                    endtask
                    endclass


