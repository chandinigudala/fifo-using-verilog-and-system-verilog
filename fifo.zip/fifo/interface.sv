interface interface_fifo(input clk,rst);
logic [3:0]din;
logic [3:0]dout;
logic e;
logic full,empty;
endinterface
