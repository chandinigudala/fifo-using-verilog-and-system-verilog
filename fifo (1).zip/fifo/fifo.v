module fifo(
  input clk,rst,en,
  input [3:0]din,
  output reg [3:0]dout,
  output full,empty
);
  reg [3:0]mem[15:0];
  reg [4:0]wp,rp;
  integer i;
  always @(posedge clk) begin
    if(rst==1) begin
      for(i=0; i<16;i=i+1) begin
        mem[i]<=4'b0000;
        
      end
      dout<=4'b0000;
        wp<=0;
        rp<=0;
    end
    else if(en==1 && !full) begin
      mem[wp[3:0]]<=din;
      wp<=wp+1;
      
    end
    else if(en==0 && !empty) begin
      dout<=mem[rp[3:0]];
      rp<=rp+1;
    end
  end
  assign full = (wp[4] != rp[4]) && (wp[3:0] == rp[3:0]);

  assign empty=(wp==rp);
endmodule
      
  
