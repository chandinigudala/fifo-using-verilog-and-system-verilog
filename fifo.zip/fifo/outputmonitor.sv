class outputmonitor;
transaction tr;
mailbox #(transaction) o2s;
virtual interface_fifo inter;
function new(input mailbox #(transaction) o2s,virtual interface_fifo inter);
this.o2s=o2s;
this.inter=inter;
endfunction
task run();
tr=new();
forever begin
@(posedge inter.clk)
tr.dout=inter.dout;
tr.display("from outputmonitor");
o2s.put(tr);
end
endtask
endclass
