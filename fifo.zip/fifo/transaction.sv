class transaction;
rand bit [3:0]din;
bit clk,rst,e;
bit [3:0]dout;
bit full,empty;
bit [4:0]wr,rd;
static int a[$];
constraint nam {!(din inside {a});}
function void post_randomize();
a.push_back(din);
endfunction
function void display(string s="from transaction");
$display("%s clk:%b,rst:%b,e:%b,rd:%d,wr:%d,full:%b,empty:%d,din:%d,dout:%d",s,clk,rst,e,rd,wr,full,empty,din,dout);
endfunction
endclass
