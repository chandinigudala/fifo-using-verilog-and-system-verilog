module dut(
input [3:0]din,
input clk,rst,e,
output reg[3:0]dout,
output empty,
output full
);
reg [3:0]mem[15:0];
reg [4:0]rd;
reg [4:0]wr;
always @(posedge clk) begin
if(rst==1) begin
    dout=0;
    //empty=0;
    //full=0;
    wr=0;
    rd=0;
    for(int i=0; i<=15;i++)
        mem[i]=0;
        end
        else begin
            if(e==1 && !full) begin
                mem[wr[3:0]]=din;
                wr=wr+1;
                end
                else if(e==0 && !empty) begin
                    dout=mem[rd[3:0]];
                    rd=rd+1;
                    end
                    end
                    end
                    assign empty={rd==wr};
                    assign full={(wr[4]!=rd[4])  && (wr[3:0]==rd[3:0])};
                    endmodule
