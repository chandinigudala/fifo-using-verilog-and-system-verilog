module tb;
  reg clk,rst,en;
  reg [3:0]din;
  wire [3:0]dout;
  wire full,empty;
  fifo dut(.clk(clk),.rst(rst),.en(en),.din(din),.dout(dout),.full(full),.empty(empty));
  initial begin
    clk=0;
  end
  always #5 clk=~clk;
  initial begin
    rst=1;#10
    rst=0; 
    write();
    #10;
    read();
     #50 $stop;
  end
    task write; 
      begin
      
      repeat (3) begin
        en=1;
      din=$random;
      #10;
   
    end
      end
    endtask
      task read; begin
        repeat (2) begin
    		en=0;
        end
      end
     
      endtask
          
   
  initial $monitor("clk:%b,rst:%b,en:%b,din:%b,dout:%b,full:%b,empty:%b",clk,rst,en,din,dout,full,empty);
endmodule
    
    
    
