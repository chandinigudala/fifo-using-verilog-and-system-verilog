program tb(interface_fifo inter);
test t;
initial begin
t=new(inter);
t.run();
end
endprogram

